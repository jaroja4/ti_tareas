<?php

return array(
    'Help on Postmark integration' => 'Ayuda sobre la integración de Matasellos',
);

