<?php

return array(
    'Help on Postmark integration' => 'Hilfe bei Postmark-Integration',
);

