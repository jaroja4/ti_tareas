<?php

return array(
    'Help on Postmark integration' => 'Ajuda na integração do Postmark',
);

