<?php

return array(
    'Help on Postmark integration' => 'Справка о Postmark интеграции',
);

