<?php

return array(
    'Help on Postmark integration' => 'Aide sur l\'intégration avec Postmark',
);

