<?php

return array(
    'Help on Postmark integration' => 'Hjälp för Postmark integration',
);

